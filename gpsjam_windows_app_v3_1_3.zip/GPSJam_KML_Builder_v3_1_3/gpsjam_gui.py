#!/usr/bin/env python3
"""GPSJam KML Builder v3.1.3 — Windows desktop application.

The user interface is rendered with pywebview.  The map renderer itself is
self-contained in assets/app.html, so it does not depend on a CDN-hosted
JavaScript mapping library.  It still requires internet access for map tiles
and the GPSJam daily CSV data.
"""
from __future__ import annotations

import os
import sys
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import webview

from gpsjam_to_kml import REGION_BOUNDS, build_kml, fetch_csv, geojson_preview, selected_cells


APP_NAME = "GPSJam KML Builder v3.1.3"
MAX_PREVIEW_FEATURES = 2200


def resource_path(relative: str) -> Path:
    """Resolve assets both from source and from a PyInstaller one-file EXE."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / relative


def documents_dir() -> Path:
    path = Path.home() / "Documents"
    return path if path.exists() else Path.home()


def normalise_levels(values: Any) -> list[str]:
    valid = {"low", "medium", "high"}
    levels = [str(value).lower() for value in (values or []) if str(value).lower() in valid]
    return [level for level in ("low", "medium", "high") if level in levels]


class Bridge:
    def __init__(self) -> None:
        self.window: webview.Window | None = None
        self.cache: dict[str, str] = {}

    def attach_window(self, window: webview.Window) -> None:
        self.window = window

    def get_config(self) -> dict[str, Any]:
        today = datetime.now(timezone.utc).date().isoformat()
        return {
            "appName": APP_NAME,
            "version": "v3.1.3",
            "date": today,
            "regions": list(REGION_BOUNDS.keys()),
            "regionBounds": {key: list(value) for key, value in REGION_BOUNDS.items()},
            "defaultOutput": str(documents_dir() / f"GPSJam_{today}_Europe.kml"),
            "mapFeatureLimit": MAX_PREVIEW_FEATURES,
        }

    def _csv(self, date: str) -> str:
        if date not in self.cache:
            self.cache[date] = fetch_csv(date)
        return self.cache[date]

    @staticmethod
    def _validate(date: str, region: str, levels: list[str]) -> str | None:
        try:
            parsed = datetime.strptime(date, "%Y-%m-%d").date()
        except ValueError:
            return "Use a valid UTC date in YYYY-MM-DD format."
        if parsed > datetime.now(timezone.utc).date():
            return "The selected UTC date is in the future."
        if region not in REGION_BOUNDS:
            return "Choose a supported region."
        if not levels:
            return "Select at least one RAG level."
        return None

    @staticmethod
    def _statistics(cells: list[dict[str, object]], counts: dict[str, int]) -> dict[str, Any]:
        total = len(cells)
        return {
            "total": total,
            "low": counts.get("low", 0),
            "medium": counts.get("medium", 0),
            "high": counts.get("high", 0),
            "lowPct": round((counts.get("low", 0) / total * 100) if total else 0, 1),
            "mediumPct": round((counts.get("medium", 0) / total * 100) if total else 0, 1),
            "highPct": round((counts.get("high", 0) / total * 100) if total else 0, 1),
            "skipped": counts.get("skipped", 0),
        }

    def preview_map(self, payload: dict[str, Any]) -> dict[str, Any]:
        date = str(payload.get("date", "")).strip()
        region = str(payload.get("region", "Europe")).strip()
        levels = normalise_levels(payload.get("levels"))
        try:
            opacity = float(payload.get("opacity", 0.70))
        except (TypeError, ValueError):
            opacity = 0.70
        validation = self._validate(date, region, levels)
        if validation:
            return {"ok": False, "error": validation}
        try:
            csv_text = self._csv(date)
            cells, counts = selected_cells(csv_text, region=region, levels=levels)
            geojson, truncated, shown = geojson_preview(cells, opacity=opacity, maximum=MAX_PREVIEW_FEATURES)
            return {
                "ok": True,
                "date": date,
                "region": region,
                "bounds": list(REGION_BOUNDS[region]),
                "geojson": geojson,
                "statistics": self._statistics(cells, counts),
                "shown": shown,
                "truncated": truncated,
                "retrievedUtc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            }
        except Exception as exc:
            return {
                "ok": False,
                "error": (
                    "Could not retrieve or parse GPSJam data. Confirm that the selected date is available "
                    f"and that the computer has internet access. Technical detail: {exc}"
                ),
            }

    def generate_kml(self, payload: dict[str, Any]) -> dict[str, Any]:
        date = str(payload.get("date", "")).strip()
        region = str(payload.get("region", "Europe")).strip()
        levels = normalise_levels(payload.get("levels"))
        output = str(payload.get("output", "")).strip()
        options = payload.get("options") or {}
        try:
            opacity = float(payload.get("opacity", 0.70))
        except (TypeError, ValueError):
            opacity = 0.70
        validation = self._validate(date, region, levels)
        if validation:
            return {"ok": False, "error": validation}
        if not output:
            return {"ok": False, "error": "Use Save As to choose an output KML file."}
        try:
            target = Path(output).expanduser()
            if target.suffix.lower() != ".kml":
                target = target.with_suffix(".kml")
            target.parent.mkdir(parents=True, exist_ok=True)
            csv_text = self._csv(date)
            kml, counts = build_kml(
                csv_text=csv_text,
                date=date,
                region=region,
                levels=levels,
                include_mgrs=bool(options.get("includeMgrs", True)),
                heatmap=bool(options.get("heatmap", True)),
                military_folders=bool(options.get("militaryFolders", True)),
                include_legend=bool(options.get("includeLegend", True)),
                opacity=opacity,
            )
            target.write_text(kml, encoding="utf-8")
            cells, _ = selected_cells(csv_text, region=region, levels=levels)
            return {
                "ok": True,
                "path": str(target),
                "statistics": self._statistics(cells, counts),
                "message": f"KML created: {target.name}",
            }
        except Exception as exc:
            return {"ok": False, "error": f"KML generation failed: {exc}"}

    def choose_output(self, suggested_filename: str) -> dict[str, Any]:
        """Show the native Windows Save As dialogue through pywebview."""
        if not self.window:
            return {"ok": False, "error": "Application window is not ready."}
        try:
            filename = Path(suggested_filename or "GPSJam_overlay.kml").name
            if not filename.lower().endswith(".kml"):
                filename += ".kml"
            result = self.window.create_file_dialog(
                webview.SAVE_DIALOG,
                directory=str(documents_dir()),
                save_filename=filename,
                file_types=("KML files (*.kml)", "All files (*.*)"),
            )
            if not result:
                return {"ok": False, "cancelled": True}
            path = result[0] if isinstance(result, (tuple, list)) else result
            target = Path(str(path))
            if target.suffix.lower() != ".kml":
                target = target.with_suffix(".kml")
            return {"ok": True, "path": str(target)}
        except Exception as exc:
            return {"ok": False, "error": f"Could not open the Windows Save As dialogue: {exc}"}

    def open_folder(self, path: str) -> dict[str, Any]:
        if not path:
            return {"ok": False, "error": "Select an output file first."}
        try:
            target = Path(path).expanduser()
            folder = target if target.is_dir() else target.parent
            folder.mkdir(parents=True, exist_ok=True)
            if sys.platform.startswith("win"):
                os.startfile(str(folder))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": f"Could not open folder: {exc}"}

    def clear_cache(self) -> dict[str, Any]:
        self.cache.clear()
        return {"ok": True}


def main() -> None:
    bridge = Bridge()
    html_file = resource_path("assets/app.html")
    window = webview.create_window(
        APP_NAME,
        url=html_file.as_uri(),
        js_api=bridge,
        width=1600,
        height=980,
        min_size=(1200, 720),
        resizable=True,
        background_color="#07111d",
    )
    bridge.attach_window(window)
    webview.start(debug=False)


if __name__ == "__main__":
    main()
