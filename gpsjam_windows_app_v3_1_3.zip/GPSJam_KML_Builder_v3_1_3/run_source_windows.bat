@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  echo Creating local virtual environment and installing requirements...
  py -3 -m venv .venv
  call .venv\Scripts\activate.bat
  python -m pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
python gpsjam_gui.py
pause
