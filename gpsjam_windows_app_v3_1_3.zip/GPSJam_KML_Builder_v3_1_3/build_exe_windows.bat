@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================================
echo GPSJam KML Builder v3.1.3 - Windows EXE builder
echo ============================================================
echo.

where py >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Python Launcher was not found.
    echo Install Python 3.11 or later from https://www.python.org/downloads/windows/
    echo Select "Add python.exe to PATH" during installation.
    pause
    exit /b 1
)

if not exist .venv (
    echo Creating local virtual environment...
    py -3 -m venv .venv
    if %errorlevel% neq 0 (
        echo ERROR: Could not create virtual environment.
        pause
        exit /b 1
    )
)

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo ERROR: Dependency installation failed.
    pause
    exit /b 1
)

echo Building standalone Windows executable...
pyinstaller --clean --noconfirm --onefile --windowed ^
  --name "GPSJam KML Builder v3.1.3" ^
  --icon "assets\gpsjam_pallas.ico" ^
  --add-data "assets;assets" ^
  --collect-all webview ^
  gpsjam_gui.py

if %errorlevel% neq 0 (
    echo ERROR: EXE build failed.
    pause
    exit /b 1
)

echo.
echo SUCCESS.
echo The EXE is here:
echo %~dp0dist\GPSJam KML Builder v3.1.3.exe
echo.
echo Note: the app needs an internet connection for GPSJam data and online map tiles.
echo Edge WebView2 Runtime is normally already present on Windows 10/11.
pause
