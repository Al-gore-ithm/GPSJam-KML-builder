#!/usr/bin/env python3
"""GPSJam CSV to KML conversion and map-preview helpers for GPSJam KML Builder v3.1.1.

GPSJam data represents aggregated ADS-B aircraft reports of low navigation accuracy.
It must not be interpreted as a direct jammer-location product.
"""
from __future__ import annotations

import argparse
import csv
import html
import io
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

try:
    import h3
except ImportError as exc:
    raise SystemExit("Missing dependency: pip install h3") from exc

REGION_BOUNDS = {
    "Worldwide": (-180.0, -90.0, 180.0, 90.0),
    "Europe": (-31.5, 34.0, 45.0, 72.5),
    "North America": (-170.0, 5.0, -50.0, 84.0),
    "South America": (-82.0, -56.0, -34.0, 13.5),
    "Asia": (25.0, -10.0, 180.0, 82.0),
    "Africa": (-20.0, -35.0, 52.0, 38.0),
    "Oceania": (110.0, -50.0, 180.0, 0.0),
}

LEVEL_NAMES = {
    "low": "GREEN / Low 0–2%",
    "medium": "AMBER / Medium 2–10%",
    "high": "RED / High >10%",
}

# KML is AABBGGRR, not #RRGGBB.
BASE_KML_COLOURS = {
    "low": "00aa00",
    "medium": "00ffff",
    "high": "0000ff",
}
MAP_COLOURS = {
    "low": "#6fcf2f",
    "medium": "#f5b800",
    "high": "#e64032",
}


def fetch_csv(date: str) -> str:
    """Fetch one daily GPSJam H3 resolution-4 CSV."""
    try:
        import requests
    except ImportError as exc:
        raise SystemExit("Missing dependency: pip install requests") from exc

    url = f"https://gpsjam.org/data/{date}-h3_4.csv"
    headers = {"User-Agent": "GPSJam-KML-Builder/3.1 (Pallas Consulting Services Ltd)"}
    response = requests.get(url, headers=headers, timeout=(15, 120))
    response.raise_for_status()
    if not response.text.strip():
        raise RuntimeError("GPSJam returned an empty data file.")
    return response.text


def choose_col(row: Dict[str, str], names: Iterable[str]) -> str | None:
    lower_map = {str(k).strip().lower(): str(k) for k in row.keys()}
    for name in names:
        if name.lower() in lower_map:
            return lower_map[name.lower()]
    return None


def cell_boundary_lonlat(cell: str) -> List[Tuple[float, float]]:
    # h3.cell_to_boundary returns (lat, lng).
    boundary = h3.cell_to_boundary(cell)
    coords = [(float(lng), float(lat)) for lat, lng in boundary]
    if coords and coords[0] != coords[-1]:
        coords.append(coords[0])
    return coords


def cell_centre_lonlat(cell: str) -> Tuple[float, float]:
    lat, lng = h3.cell_to_latlng(cell)
    return float(lng), float(lat)


def classify(good: int, bad: int) -> Tuple[str, float, str]:
    """Use GPSJam's denoised percentage: 100 * (bad - 1) / (good + bad)."""
    total = good + bad
    pct_bad = (max(bad - 1, 0) / total * 100.0) if total else 0.0
    if pct_bad > 10.0:
        return LEVEL_NAMES["high"], pct_bad, "high"
    if pct_bad >= 2.0:
        return LEVEL_NAMES["medium"], pct_bad, "medium"
    return LEVEL_NAMES["low"], pct_bad, "low"


def row_values(row: Dict[str, str]) -> Tuple[str, int, int]:
    h3_col = choose_col(row, ["h3", "h3_index", "cell", "hex", "hex_id", "h3_cell"])
    good_col = choose_col(row, ["good", "num_good", "good_count", "n_good", "good_aircraft"])
    bad_col = choose_col(row, ["bad", "num_bad", "bad_count", "n_bad", "low", "low_count", "bad_aircraft"])
    if not h3_col or not good_col or not bad_col:
        values = list(row.values())
        if len(values) < 3:
            raise ValueError(f"Cannot parse CSV row: {row}")
        return values[0].strip(), int(float(values[1])), int(float(values[2]))
    return row[h3_col].strip(), int(float(row[good_col])), int(float(row[bad_col]))


def in_region(lon: float, lat: float, region: str) -> bool:
    min_lon, min_lat, max_lon, max_lat = REGION_BOUNDS.get(region, REGION_BOUNDS["Worldwide"])
    return min_lon <= lon <= max_lon and min_lat <= lat <= max_lat


def parse_csv_rows(csv_text: str):
    sample = csv_text[:4096]
    try:
        has_header = csv.Sniffer().has_header(sample)
    except csv.Error:
        has_header = True
    stream = io.StringIO(csv_text)
    if has_header:
        yield from csv.DictReader(stream)
    else:
        for row in csv.reader(stream):
            if len(row) >= 3:
                yield {"h3": row[0], "good": row[1], "bad": row[2]}


def selected_cells(csv_text: str, region: str = "Worldwide", levels: Sequence[str] = ("medium", "high")) -> Tuple[List[Dict[str, object]], Dict[str, int]]:
    requested = {str(level).lower() for level in levels}
    cells: List[Dict[str, object]] = []
    counts = {"low": 0, "medium": 0, "high": 0, "skipped": 0}

    for row in parse_csv_rows(csv_text):
        try:
            cell, good, bad = row_values(row)  # type: ignore[arg-type]
            level_name, pct_bad, level_id = classify(good, bad)
            if level_id not in requested:
                continue
            lon, lat = cell_centre_lonlat(cell)
            if not in_region(lon, lat, region):
                continue
            coords = cell_boundary_lonlat(cell)
            if len(coords) < 4:
                raise ValueError("H3 cell boundary was incomplete")
        except Exception:
            counts["skipped"] += 1
            continue

        counts[level_id] += 1
        cells.append({
            "cell": cell,
            "good": good,
            "bad": bad,
            "level_name": level_name,
            "pct_bad": pct_bad,
            "level_id": level_id,
            "lon": lon,
            "lat": lat,
            "coords": coords,
        })
    return cells, counts


def alpha_hex(value: int) -> str:
    return f"{max(0, min(255, int(value))):02x}"


def style_colour(level_id: str, pct_bad: float, heatmap: bool, opacity: float) -> str:
    """KML colour in AABBGGRR; opacity is a 0–1 user setting."""
    if heatmap:
        if level_id == "low":
            base_alpha = 60 + min(35, int(pct_bad * 15))
        elif level_id == "medium":
            base_alpha = 95 + min(60, int((pct_bad - 2.0) * 8))
        else:
            base_alpha = 150 + min(80, int((pct_bad - 10.0) * 2.5))
    else:
        base_alpha = {"low": 95, "medium": 125, "high": 155}.get(level_id, 125)
    return alpha_hex(round(base_alpha * max(0.15, min(1.0, opacity)))) + BASE_KML_COLOURS[level_id]


def lat_band(lat: float) -> str:
    bands = "CDEFGHJKLMNPQRSTUVWX"
    if lat < -80:
        return "C"
    if lat >= 84:
        return "X"
    return bands[int((lat + 80) // 8)]


def approx_mgrs(lon: float, lat: float) -> str:
    """Lightweight orientation label, deliberately not a survey-grade MGRS coordinate."""
    zone = max(1, min(60, int((lon + 180.0) / 6.0) + 1))
    return f"{zone}{lat_band(lat)} approx {abs(lat):05.2f}{'N' if lat >= 0 else 'S'} {abs(lon):06.2f}{'E' if lon >= 0 else 'W'}"


def style_block(style_id: str, level_id: str, pct: float, heatmap: bool, opacity: float) -> str:
    colour = style_colour(level_id, pct, heatmap, opacity)
    width = {"low": 0.35, "medium": 0.55, "high": 0.8}.get(level_id, 0.5)
    return f'<Style id="{style_id}"><LineStyle><color>b4000000</color><width>{width}</width></LineStyle><PolyStyle><color>{colour}</color></PolyStyle></Style>'


def build_kml(
    csv_text: str,
    date: str,
    region: str = "Worldwide",
    levels: Sequence[str] = ("medium", "high"),
    include_mgrs: bool = False,
    heatmap: bool = True,
    military_folders: bool = True,
    include_legend: bool = True,
    opacity: float = 0.70,
) -> Tuple[str, Dict[str, int]]:
    cells, counts = selected_cells(csv_text, region=region, levels=levels)
    by_level = {"low": [], "medium": [], "high": []}
    mgrs_marks: List[str] = []
    styles: List[str] = []

    if heatmap:
        for level in ("low", "medium", "high"):
            for bucket in range(0, 101, 5):
                styles.append(style_block(f"{level}_{bucket}", level, float(bucket), True, opacity))
    else:
        styles = [
            style_block("low", "low", 1.0, False, opacity),
            style_block("medium", "medium", 5.0, False, opacity),
            style_block("high", "high", 20.0, False, opacity),
        ]

    for item in cells:
        level = str(item["level_id"])
        pct = float(item["pct_bad"])
        style_id = level if not heatmap else f"{level}_{int(min(100, max(0, round(pct / 5.0) * 5)))}"
        coords = item["coords"]  # type: ignore[assignment]
        coordinate_text = " ".join(f"{lon:.7f},{lat:.7f},0" for lon, lat in coords)  # type: ignore[misc]
        mgrs = approx_mgrs(float(item["lon"]), float(item["lat"]))
        description = html.escape(
            f"Date (UTC): {date}\nRegion filter: {region}\nH3 cell: {item['cell']}\n"
            f"Good aircraft reports: {item['good']}\nLow-accuracy reports: {item['bad']}\n"
            f"GPSJam-aligned low-accuracy percentage: {pct:.2f}%\nClassification: {item['level_name']}\n"
            f"Approx MGRS-style locator: {mgrs}\n\n"
            "Caution: this overlay represents aircraft-reported low navigation accuracy by H3 cell, not transmitter locations."
        )
        by_level[level].append(f"""
      <Placemark>
        <name>{html.escape(str(item['level_name']))}</name>
        <styleUrl>#{style_id}</styleUrl>
        <description>{description}</description>
        <ExtendedData>
          <Data name="date_utc"><value>{date}</value></Data>
          <Data name="region"><value>{html.escape(region)}</value></Data>
          <Data name="h3"><value>{html.escape(str(item['cell']))}</value></Data>
          <Data name="good_aircraft"><value>{item['good']}</value></Data>
          <Data name="low_accuracy_aircraft"><value>{item['bad']}</value></Data>
          <Data name="pct_low_accuracy"><value>{pct:.4f}</value></Data>
          <Data name="classification"><value>{html.escape(str(item['level_name']))}</value></Data>
          <Data name="approx_mgrs"><value>{html.escape(mgrs)}</value></Data>
        </ExtendedData>
        <Polygon><tessellate>1</tessellate><outerBoundaryIs><LinearRing><coordinates>{coordinate_text}</coordinates></LinearRing></outerBoundaryIs></Polygon>
      </Placemark>""")
        if include_mgrs:
            mgrs_marks.append(f"""
      <Placemark><name>{html.escape(mgrs)}</name><description>{description}</description>
        <Point><coordinates>{float(item['lon']):.7f},{float(item['lat']):.7f},0</coordinates></Point>
      </Placemark>""")

    high_folder = "03_HIGH — degraded GNSS environment" if military_folders else "High >10%"
    medium_folder = "02_MEDIUM — elevated GNSS disruption indicators" if military_folders else "Medium 2–10%"
    low_folder = "01_LOW — low disruption indicators" if military_folders else "Low 0–2%"
    mgrs_folder = ""
    if include_mgrs:
        mgrs_folder = f"<Folder><name>Approx MGRS centre placemarks</name>{''.join(mgrs_marks)}</Folder>"
    legend_folder = ""
    if include_legend:
        legend_folder = """
    <Folder><name>Legend and provenance</name>
      <Placemark><name>GREEN / Low</name><description>0–2% GPSJam low navigation accuracy.</description></Placemark>
      <Placemark><name>AMBER / Medium</name><description>2–10% GPSJam low navigation accuracy.</description></Placemark>
      <Placemark><name>RED / High</name><description>&gt;10% GPSJam low navigation accuracy.</description></Placemark>
      <Placemark><name>Data caveat</name><description>GPSJam is derived from aggregated ADS-B aircraft navigation accuracy reports; it is not a jammer-location product.</description></Placemark>
    </Folder>"""

    title = f"GPSJam H3 overlay — {region} — {date}"
    source_note = html.escape(
        "GPSJam H3 resolution-4 polygon overlay. The map uses ADS-B aircraft reports of low navigation accuracy. "
        "Green is 0–2%, amber 2–10%, and red >10% low accuracy. The data is not a direct geolocation of jammer transmitters. "
        "Region filters are broad geographic bounding boxes. Approximate MGRS labels are orientation aids only."
    )
    kml = f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>{html.escape(title)}</name>
    <description>{source_note}</description>
    {''.join(styles)}
    <Folder><name>GPSJam Low Navigation Accuracy</name>
      <Folder><name>{html.escape(low_folder)}</name>{''.join(by_level['low'])}</Folder>
      <Folder><name>{html.escape(medium_folder)}</name>{''.join(by_level['medium'])}</Folder>
      <Folder><name>{html.escape(high_folder)}</name>{''.join(by_level['high'])}</Folder>
    </Folder>
    {mgrs_folder}
    {legend_folder}
  </Document>
</kml>
"""
    return kml, counts


def sample_for_preview(cells: List[Dict[str, object]], maximum: int = 5500) -> Tuple[List[Dict[str, object]], bool]:
    """Bound Leaflet payload sizes while preserving the distribution of RAG levels."""
    if len(cells) <= maximum:
        return cells, False
    grouped = {"low": [], "medium": [], "high": []}
    for cell in cells:
        grouped[str(cell["level_id"])].append(cell)
    result: List[Dict[str, object]] = []
    total = len(cells)
    for level in ("low", "medium", "high"):
        group = grouped[level]
        if not group:
            continue
        allocation = max(1, round(maximum * len(group) / total))
        stride = max(1, math.ceil(len(group) / allocation))
        result.extend(group[::stride])
    return result[:maximum], True


def geojson_preview(cells: List[Dict[str, object]], opacity: float, maximum: int = 5500) -> Tuple[Dict[str, object], bool, int]:
    preview_cells, truncated = sample_for_preview(cells, maximum)
    features = []
    global_opacity = max(0.15, min(1.0, float(opacity)))
    for item in preview_cells:
        level = str(item["level_id"])
        pct = float(item["pct_bad"])
        severity = 0.55 if level == "low" else 0.70 if level == "medium" else 0.90
        # Increase the visual strength within each RAG band but retain clear category distinction.
        if level == "high":
            severity = min(1.0, severity + min(0.10, max(0.0, (pct - 10.0) / 100.0)))
        coords = [[float(lon), float(lat)] for lon, lat in item["coords"]]  # type: ignore[misc]
        features.append({
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [coords]},
            "properties": {
                "cell": str(item["cell"]), "level": level, "level_name": str(item["level_name"]),
                "pct": round(pct, 3), "good": int(item["good"]), "bad": int(item["bad"]),
                "fill": MAP_COLOURS[level], "opacity": round(global_opacity * severity, 3),
                "centre": [float(item["lat"]), float(item["lon"])],
            },
        })
    return {"type": "FeatureCollection", "features": features}, truncated, len(preview_cells)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a GPSJam KML overlay.")
    parser.add_argument("--date", default=datetime.now(timezone.utc).date().isoformat())
    parser.add_argument("--csv", help="Optional local CSV instead of downloading GPSJam data.")
    parser.add_argument("--output", default="gpsjam_overlay.kml")
    parser.add_argument("--region", choices=list(REGION_BOUNDS), default="Worldwide")
    parser.add_argument("--levels", nargs="+", choices=["low", "medium", "high"], default=["medium", "high"])
    parser.add_argument("--mgrs", action="store_true")
    parser.add_argument("--no-heatmap", action="store_true")
    parser.add_argument("--plain-folders", action="store_true")
    parser.add_argument("--no-legend", action="store_true")
    parser.add_argument("--opacity", type=float, default=0.70)
    args = parser.parse_args()
    csv_text = Path(args.csv).read_text(encoding="utf-8") if args.csv else fetch_csv(args.date)
    kml, counts = build_kml(
        csv_text, args.date, args.region, args.levels,
        include_mgrs=args.mgrs, heatmap=not args.no_heatmap,
        military_folders=not args.plain_folders, include_legend=not args.no_legend,
        opacity=args.opacity,
    )
    Path(args.output).write_text(kml, encoding="utf-8")
    print(f"Wrote {args.output}")
    print(counts)

if __name__ == "__main__":
    main()
